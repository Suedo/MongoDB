#!/bin/sh

# re-generate the drdl file to map all collections
mongodrdl --host localhost -d webshop -o webshop.drdl

# boot up mongosqld with the new file
mongosqld --mongo-uri mongodb://localhost --schema webshop.drdl -vv

# connect to sql client
mysql --port 3307 --protocol TCP -e "use webshop; show tables;"

# express a join between `products` and `attributes`
# mysql> SELECT p.product_uid, p._id, a._id, a.name
# FROM products p, attributes a
# WHERE a.product_uid = p.product_uid AND p.product_uid < 100002;
mysql --port 3307 --protocol TCP \
-e "use webshop;SELECT p.product_uid, p._id, a._id, a.name
FROM products p, attributes a
WHERE a.product_uid = p.product_uid AND p.product_uid < 100002;"

# check `mongod` log file
cat data/db/log | grep '$lookup'
