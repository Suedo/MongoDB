#!/bin/sh

# deploy vagrant machine
vagrant up

# check vagrant machine status
vagrant status

# ssh connection to vagrant machine
vagrant ssh

# making sure that data/db folder is created
mkdir -p data/db

# boot up mongod
mongod --dbpath data/db --fork --logpath data/db/log

# restore dataset
mongorestore -d webshop /dataset/webshop

# check product collection document structure
mongo webshop --eval "db.products.findOne()"

# check attributes collection document structure
mongo webshop --eval "db.attributes.findOne()"

# generate the drdl file for webshop.products namespace
mongodrdl --host localhost -d webshop -c products -o webshop_products.drdl

# output the drdl file
cat webshop_products.drdl
