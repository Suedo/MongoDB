#!/bin/sh

# boot up mongosqld
mongosqld --mongo-uri mongodb://localhost --schema webshop_products.drdl -vv

# connect to mongosqld from a sql client
mysql --port 3307 --protocol TCP

# show databases command
# mysql> show databases;
mysql --port 3307 --protocol TCP -e "show databases;"

# switch to webshop database and show tabels;
# mysql> use webshop
# mysql> show tables;
mysql --port 3307 --protocol TCP -e "use webshop; show tables;"

# mysql> SELECT * FROM products LIMIT 1;
mysql --port 3307 --protocol TCP -e "use webshop;SELECT * FROM products LIMIT 1;"

# mysql> SELECT product_uid FROM products LIMIT 1;
mysql --port 3307 --protocol TCP \
-e "use webshop;SELECT product_uid FROM products LIMIT 1;"

# mysql> SELECT _id, SUBSTRING(`product_description`, 1, 5 ) as `desc`,
# product_uid FROM products LIMIT 10;
mysql --port 3307 --protocol TCP \
-e "use webshop;SELECT _id, SUBSTRING(\`product_description\`, 1, 5 )as \`desc\`,
product_uid FROM products LIMIT 10;"
