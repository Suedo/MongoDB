#!/bin/sh

# create inception collection with one deep nested document
mongo nested --eval "db.inception.insert({
  'level1':{
    'level2':[
    {
      'level3inner1': 1,
      'level3inner2': 'abc',
      'level3inner3': {
        'level4': {
          level5: 'hello'
        }
      }
    }
    ]
  }
})"

# create drdl file
mongodrdl --host localhost -d nested -o nested.drdl

# initiate mongosqld
mongosqld --mongo-uri mongodb://localhost --schema nested.drdl

# show tables
mysql --protocol tcp --port 3307 -e "use nested; show tables;"

# SELECT inner fields
mysql --protocol tcp --port 3307 -e "use nested;
SELECT \`level1.level2.level3inner2\` as inner2
FROM inception_level1_level2
WHERE \`level1.level2.level3inner2\` = \"abc\";"

# generate drdl file with custom filter field
mongodrdl --host localhost -d nested -f mongoquery -o nested.drdl

# describe table inception
mysql --protocol tcp --port 3307 -e "use nested;
SHOW COLUMNS FROM inception_level1_level2;"

# SELECT all fields from table inception
mysql --protocol tcp --port 3307 -e "use nested;
SELECT * FROM inception_level1_level2;"

# native mongodb query through SQL statement
mysql --protocol tcp --port 3307 -e "use nested;
SELECT * FROM inception_level1_level2
WHERE mongoquery = '{\"level1.level2\": {\"\$type\": \"object\"}}';"
