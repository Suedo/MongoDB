#!/bin/sh

# launch mongod server
mongod -f /shared/authmongo.cnf

# connect to the server using the mongo shell
mongo --ssl --sslPEMKeyFile /shared/certs/client.pem \
--sslCAFile /shared/certs/ca.pem --host m034:27000

# create root user
# use admin
# db.createUser({user: 'alice', pwd: 'secret', roles:['root']})
mongo admin --ssl --sslPEMKeyFile /shared/certs/client.pem \
--sslCAFile /shared/certs/ca.pem --host m034:27000 \
--eval "db.createUser({user: 'alice', pwd: 'secret', roles:['root']})"

# create biuser
# use admin
# db.createUser({user: 'biuser', pwd: 'pass', roles:[{role:'read', db:'twitter'}}]})
mongo admin --ssl --sslPEMKeyFile /shared/certs/client.pem \
--sslCAFile /shared/certs/ca.pem --host m034:27000 \
-u alice -p secret \
--eval "db.createUser({user: 'biuser', pwd: 'pass', roles:[{role:'read', db:'twitter'}]})"

# import twitter dataset
mongoimport --authenticationDatabase admin --ssl \
--sslPEMKeyFile /shared/certs/client.pem --sslCAFile /shared/certs/ca.pem \
--host m034:27000 -u alice -p secret -d twitter -c tweets /dataset/100tweets.json

# generate drdl file
mongodrdl --authenticationDatabase admin --ssl \
--sslPEMKeyFile /shared/certs/client.pem --sslCAFile /shared/certs/ca.pem \
--host m034:27000 -u biuser -p pass -d twitter -o twitter.drld

# launch mongosqld
mongosqld --mongo-ssl --mongo-sslPEMKeyFile /shared/certs/client.pem \
--mongo-sslCAFile /shared/certs/ca.pem --mongo-uri mongodb://m034:27000 \
--schema twitter.drld --auth --addr 0.0.0.0:3307 -vvv \
--sslPEMKeyFile /shared/certs/mongosqld-server.pem

# set environment variable to enable mysql to send password in clear text
export LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN=1

# connect with mysql client
mysql --protocol tcp --port 3307 -u biuser?source=admin -p --ssl \
--ssl-cert /shared/certs/mongosqld-server.pem --ssl-ca /shared/certs/ca.pem
