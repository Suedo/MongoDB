# Scripts used in the Improved Logging lesson

cat create-replica-set-for-initial-sync-demo.sh

 ./create-replica-set-for-initial-sync-demo.sh  # This will spin up your replica set

mongorestore --drop --gzip --numInsertionWorkersPerCollection 4 m034-initial-sync-mongodump

cat resync-mongod-port-27019.sh

./resync-mongod-port-27019.sh

echo "rs.status()" | mongo

less ./three-member-replica-set/3/mongod.log
