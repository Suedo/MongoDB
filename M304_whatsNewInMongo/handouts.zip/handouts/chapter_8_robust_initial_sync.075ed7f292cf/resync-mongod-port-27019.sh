#!/usr/bin/env bash

current_dir=`pwd`
data_dir=$current_dir/three-member-replica-set

echo "This script will:"
echo "  - Kill your mongod on localhost:27019"
echo "  - Remove the $data_dir/3 directory (if present)"
echo "  - Restart the server process pointing to $data_dir/3"

# The following is modified from James' response to this question:
# http://stackoverflow.com/questions/3231804/in-bash-how-to-add-are-you-sure-y-n-to-any-command-or-alias/3231821#3231821
read -r -p "Are you sure you want to continue? [y/N] " response
case $response in
    [yY][eE][sS]|[yY]) 
        ;;
    *)
        echo "You responded \"$response\". Exiting."
        exit
        ;;
esac


echo "Shutting down the server on port 27019, and deleting all of its files."
echo "db.shutdownServer()" | mongo --port 27019 admin
rm -r "$data_dir/3/"
mkdir "$data_dir/3/"
wait
echo "Relaunching mongod on port 27019."
mongod --replSet initialSync --port 27019 --dbpath "$data_dir/3" --logpath "$data_dir/3/mongod.log" --wiredTigerCacheSizeGB 0.5 --fork
wait
echo "Done relaunching mongod on port 27019. Its initial sync should be in progress shortly."
echo "Check $data_dir/3/mongod.log for more information."
