# Scripts for the intra-cluster compression lesson

cat demo-intra-cluster-compression.sh

./demo-intra-cluster-compression.sh

echo 'someData = [] for (i=1; i<=1000; i++) { someData.push( { data : "FILLERFILLERFILLERFILLERFILLERFILLER" } ) }; db.someData.insertMany(someData) ' | mongo
echo 'servStat = db.serverStatus(); printjson(servStat.network)' | mongo
