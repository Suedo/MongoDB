#!/usr/bin/env bash
current_dir=`pwd`
data_dir=$current_dir/three-member-replica-set
echo "This script will:"
echo "  - Kill any running mongo, mongod, or mongos processes"
echo "  - Remove the $data_dir directory (if present)"
echo "  - (Re)build $data_dir, and spin up a 3-member replica set in $data_dir/{1,2,3}"
echo "  - Initialize the member of the replica set at \"localhost:27017\""
echo "  - Add a secondary on port 27018"
echo "  - Add a secondary on port 27019"

# The following is modified from James' response to this question:
# http://stackoverflow.com/questions/3231804/in-bash-how-to-add-are-you-sure-y-n-to-any-command-or-alias/3231821#3231821
read -r -p "Are you sure you want to continue? [y/N] " response
case $response in
    [yY][eE][sS]|[yY]) 
        ;;
    *)
        echo "You responded \"$response\". Exiting."
        exit
        ;;
esac

echo -e "\nFinding all mongo, mongod, and mongos processes on this machine. Here they are:"
ps -ef | grep mongo
echo -e "\nKilling all mongo, mongod, and mongos processes."
killall mongo mongod mongos
echo -e "\nWaiting 5 seconds for the server/router processes to spin down."
sleep 5
echo -e "\nDeleting your $data_dir directory."
rm -rf $data_dir
echo -e "\nCreating data files in $data_dir ."
mkdir $data_dir
mkdir $data_dir/{1,2,3}
echo -e "\nAbout to spin up your 3 mongod servers."
echo -e "\nSpinning up the first process."
mongod --dbpath $data_dir/1 --logpath $data_dir/1/mongod.log --port 27017 --replSet initialSync --wiredTigerCacheSizeGB 0.5 --fork 
echo -e "\nSpinning up the second process."
mongod --dbpath $data_dir/2 --logpath $data_dir/2/mongod.log --port 27018 --replSet initialSync --wiredTigerCacheSizeGB 0.5 --fork
echo -e "\nSpinning up the third process."
mongod --dbpath $data_dir/3 --logpath $data_dir/3/mongod.log --port 27019 --replSet initialSync --wiredTigerCacheSizeGB 0.5 --fork
echo -e "\nServers are spun up. Initializing the replica set on the first server (port 27017)."
echo 'rs.initiate({ "_id" : "initialSync", "members" : [ { "_id" : 0, "host" : "localhost:27017", "priority": 2 } ] })' | mongo
echo -e "\nAbout to add the second member."
echo 'rs.add("localhost:27018")' | mongo
echo -e "\nAbout to add the third member."
echo 'rs.add("localhost:27019")' | mongo
echo -e "\nIf everything initiated properly, you should now be able to connect to your server processes on ports 27017, 27018, and 27019."
