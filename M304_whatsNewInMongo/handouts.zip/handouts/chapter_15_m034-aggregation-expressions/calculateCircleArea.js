db.circles.aggregate( [ 
{
    "$project":
    {
        "circle": "$name",  // could also use "$$CURRENT.name"
        "radius": "$$CURRENT.radius",  // could also use "$radius"
        "area": 
        {
            "value":
            {
                "$multiply":
                [
                    { "$literal": Math.PI },
                    {
                        "$pow":
                        [
                            "$radius.value",
                            { "$literal": 2 }
                        ]
                    }
                ]
            },
            "units":
            {
                "$cond": 
                {
                    "if":
                    {
                        "$eq": [ { "$literal": "cm" }, "$radius.units" ]
                    },
                    "then":
                    {
                        "$literal": "cm^2"
                    },
                    "else":
                    {
                        "$literal": "Unknown"
                    }
                }
            }
        }
    }
} ] )
