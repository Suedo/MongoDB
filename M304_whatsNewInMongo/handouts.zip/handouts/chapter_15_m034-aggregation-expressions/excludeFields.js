use m034;
db.buildings.drop();
db.buildings.insertMany( [
  { "_id" : 1, "name" : "One World Trade Center",
    "height" : { "value" : 1776, "units" : "ft" }, "yearBuilt" : 2014 },
  { "_id" : 2, "name" : "432 Park Ave",
    "height" : { "value" : 1398, "units" : "ft" }, "yearBuilt" : 2015 },
  { "_id" : 3, "name" : "Empire State Building",
    "height" : { "value" : 1250, "units" : "ft" }, "yearBuilt" : 1931 }
] );  // source: https://www.emporis.com/city/101028/new-york-city-ny-usa

print('');
db.buildings.aggregate( [
  { "$project" : { "height" : 0 } } ] );
