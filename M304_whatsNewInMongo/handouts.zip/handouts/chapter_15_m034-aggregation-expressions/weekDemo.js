use m034;
db.datetimeOperators.drop();
db.datetimeOperators.insertMany( [
  { "description": "1 July, 2016 (Friday)", "dt" : ISODate("2016-07-01") },
  { "description": "1 January, 2016 (Friday)", "dt" : ISODate("2016-01-01") },
  { "description": "4 January, 2016 (Monday)", "dt" : ISODate("2016-01-04") } ] );
db.datetimeOperators.aggregate( [
  {
    "$project" : 
    {
      "_id" : 0,
      "dateDescription" : "$description",
      " $isoWeek" : 
      {
        "operatorDescription" : "Week of year of the ISODate",
        "value" : { "$isoWeek" : "$dt" }
      },
      " $isoWeekYear" :
      {
        "operatorDescription" : "Year that starts the week of the ISODate.",
        "value" : { "$isoWeekYear" : "$dt" }
      },
      " $isoDayOfWeek" :
      {
        "operatorDescription" : "Day of week of the ISODate.",
        "value" : { "$isoDayOfWeek" : "$dt" }
      }
    }
  } ] ).pretty();
