use m034;
db.reverseArray.drop();
db.reverseArray.insertMany( [ 
  { "_id" : "orderedNumbers", "orderedArray" : [ 1, 2, 3 ] },
  { "_id" : "orderedLetters", "orderedArray" : [ 'a', 'b', 'c' ] },
  { "_id" : "nestedNumbers", "orderedArray" : [ [ 1, 2 ], [ 3, 4 ], [ 5, 6 ] ] }
] );
db.reverseArray.aggregate( [ 
  {
    "$project" : 
    {
      "reversedArray" : { "$reverseArray" : "$orderedArray" }
    }
  } ] );
