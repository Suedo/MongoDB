use m034;
db.rangeDemo.drop();
db.rangeDemo.insertMany( [
  { "_id" : "1 to 9", "start" : 1, "end" : 10, "step" : 1 },
  { "_id" : "Evens", "start" : 2, "end" : 10, "step" : 2 },
  { "_id" : "Odds", "start" : 1, "end" : 10, "step" : 2 },
  { "_id" : "DescendingEvens", "start" : 8, "end" : 0, "step" : -2 }
] );
db.rangeDemo.aggregate( [ 
  {
    "$project" :
    {
      "newArray" :
      {
        "$range" : [ "$start", "$end", "$step" ]
      }
    }
  }
] );
