use m034;
db.zipDemo.drop();
db.zipDemo.insertMany( [
  { "pets" : [ "Tom", "Bugs", "Tweety" ], "species" : [ "mouse", "bunny","canary" ] },
] );
db.zipDemo.aggregate( [ 
  {
    "$project" : 
    {
      "zippedArray" : 
      {
        "$zip" : 
        {
          "inputs" : [ "$pets", "$species" ]
        }
      }
    }
  }
] ).pretty();
