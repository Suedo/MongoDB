use m034;
db.switchDemo.drop();
db.switchDemo.insertMany( [ 
        { "n1" : 0, "n2" : 3 }, { "n1" : 1, "n2" : 3 },
        { "n1" : 2, "n2" : 3 }, { "n1" : 3, "n2" : 3 },
        { "n1" : 4, "n2" : 3 }, { "n1" : 5, "n2" : 3 } ] );
db.switchDemo.aggregate( [ 
  {
    "$project" :
    {
      "_id" : 0,
      "n1" : 1,
      "n2" : 1,
      "relationship" :
      {
        "$switch" :
        {
          "branches" : [
            {
                "case" : { "$eq" : [ "$n1", "$n2" ] },
                "then" : "n1 is equal to n2"
            }, {
                "case" : { "$gt" : [ "$n1", "$n2" ] },
                "then" : "n1 is greater than n2"
            }, {
                "case" : { "$lt" : [ "$n1", "$n2" ] },
                "then" : "n1 is less than n2"
            } ]
        }
      }
    }
  } ] );
