use m034;
db.countDemo.drop();
db.countDemo.insertMany( [ 
  { "_id" : 1 }, { "_id" : 2 }, { "_id" : 3 }, { "_id" : 4 },
  { "_id" : 5 } ] )
db.countDemo.aggregate( [ { "$match" : { "_id" : { "$lte" : 3 } } },
                          { "$count" : "numberOfDocuments" } ] );
