use m034;
db.findingElements.drop();
db.findingElements.insertMany( [
  { "_id" : "findWill", "arr" : [ "Norberto", "Shannon", "Will" ], "elem" : "Will" },
  { "_id" : "findNumber5", "arr" : [ 1, 2, 3, 4, 5, 5 ], "elem" : 5 },
  { "_id" : "findNumber7", "arr" : [ 1, 2, 3, 4, 5 ], "elem" : 7 }
   ] );
db.findingElements.aggregate( [
  {
    "$project" : 
    {
      "inArray" :
      {
        "$in" : [ "$elem", "$arr" ]
      },
      "arrayIndex" :
      {
        "$indexOfArray" : [ "$arr", "$elem" ]
      }
    }
  } ] ).pretty();
