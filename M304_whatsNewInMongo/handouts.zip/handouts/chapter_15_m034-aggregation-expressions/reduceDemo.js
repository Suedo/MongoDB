use m034;
db.agg.drop();
print("Inserting the document, { numbers : [ 1, 2, 3 ] }, into the 'm034.agg' collection.'")

db.agg.insertOne( { "numbers" : [ 1, 2, 3 ] } );
print("Now performing an aggregation query with a $project stage that uses $reduce to sum that array.")
db.agg.aggregate( [
{
  "$project" :
  {
    "sumOfNumbers" :
    {
      "$reduce" :
      {
        "input" : "$numbers",
        "initialValue" : 0,
        "in" : 
        {
          "$add": [ "$$this", "$$value" ]
        }
      }
    },
    "using" : "reduce"
  }
} ] );
print("Now going to perform the same algorithm, but with a $sum expression.")
db.reduceDemo.aggregate( [
{
  "$project" :
  {
    "sumOfNumbers" :
    {
      "$sum" : "$numbers"
    },
    "using" : "sum"
  }
} ] );
