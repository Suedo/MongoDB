use m034;
db.typeDemo.drop();
db.typeDemo.insertMany( [ 
  { "field" : "a" },
  { "field" : /a/ },
  { "field" : NumberLong(627) },
  { "field" : { "x" : 1 } },
  { "field" : [ 1, 2, 3 ] },
  { }
] )

db.typeDemo.aggregate( [ 
  { 
      "$project" : 
      {
        "_id" : 0,
        "value" : "$field",
        "type" : { "$type" : "$field" }
      }
  } ] );
