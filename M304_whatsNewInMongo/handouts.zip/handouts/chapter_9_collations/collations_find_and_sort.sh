#!/bin/sh

# query all elements and sort ascending on field `name`
mongo collations --eval "
  db.users_portugal.find().sort({'name': 1})
"

# explain the previous query
mongo collations --eval "
  db.users_portugal.find().sort({'name': 1}).explain()
"

# get collection infos
mongo collations --eval "
  db.getCollectionInfos()
"

# query using `_id` field using a different collation
mongo collations --eval "
  db.users_portugal.find({'_id': {'\$exists': 1}}).collation(
    {'locale': 'fr', 'strength' : 4}).sort({'name': 1}).explain()
"

#import deserts dataset
mongoimport -d collations -c deserts desserts.json

# query on deserts, which requires several different locales
mongo collations --eval "
  db.deserts.find({}, {'name': 1, '_id': 0, 'sold_in': 1})
"


# query deserts sold in Spain sorted using `es` locale
mongo collations --eval "
  db.deserts.find({'sold_in': 'ES'}).collation(
    {'locale': 'es'}
  ).sort({'name':-1})
"
