#!/bin/sh

# create collection with default collation
mongo collations --eval "
db.createCollection('users_portugal',
  {'collation': {
    'locale': 'pt'}
  }
)"

# insert some documents
mongo collations --eval "
  db.users_portugal.insert({
    'name': 'Norberto',
    'type': 'Avançado',
    'role': 'Administration'
  });
  db.users_portugal.insert({
    'name': 'Nólito',
    'type': 'Médio',
    'role': 'Academic'
  });
"

# create index on `name` using inherit default collection collation
mongo collations --eval "
  db.users_portugal.createIndex({'name':1})
"

# list `users_portugal` indexes
mongo collations --eval "
  db.users_portugal.getIndexes()
"

# create index on `role` with different collation
mongo collations --eval "
  db.users_portugal.createIndex(
    {'role':1},
    {'collation': {'locale': 'en'}}
  )
"
# list `users_portugal` indexes again
mongo collations --eval "
  db.users_portugal.getIndexes()
"

# create 2 indexes with the same patter but with different collation and specific index name
mongo collations --eval "
  db.users_portugal.createIndex(
    {'name':1},
    {'collation': {'locale': 'en'}, 'name': 'name_1_en'}
  )
"
