#!/bin/sh

# create view with collation
mongo collations --eval "
  db.createView('names_exist', 'names',
    [{ '\$match': {'names': {'\$exists': 1}}}],
    { 'collation': {'locale': 'pt', 'strength': 2, numericOrdering: true}}
  )
"

# get collections info
mongo collations --eval "
  db.getCollectionInfos()
"

# create view with no collation
mongo collations --eval "
  db.createView('names_nocollation', 'names',
    [{ '\$match': {'names': {'\$exists': 1}}}]
  )
"

# get collections info
mongo collations --eval "
  db.getCollectionInfos()
"

# create view with out of an existing view
mongo collations --eval "
  db.createView('names_and_age', 'names_exist',
    [{ '\$match': {'age': {'\$exists': 1}}}],
    { 'collation': {'locale': 'fr', 'strength': 3, numericOrdering: true}}
  )
"

# query override views collation
mongo collations --eval "
  db.names_exist.find({'name': 'Norberto'}).collation(
    {'locale': 'pt', 'strength': 1})
"
