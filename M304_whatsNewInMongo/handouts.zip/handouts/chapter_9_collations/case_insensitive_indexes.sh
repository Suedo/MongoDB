#!/bin/sh

# create a collection with a collation
mongo collations --eval "
  db.createCollection('names',
  {'collation': {'locale': 'pt', 'strength': 1}})
"

# insert documents
mongoimport -d collations -c names < names.json

# find names matching `ave`
mongo collations --eval "
  db.names.find({'name': 'ave'})
"

# create index with different collation
mongo collations --eval "
  db.names.createIndex({'name': 1},
    {'collation': {'locale': 'pt', 'strength': 2}}
  )
"

# query that matches the index selection
mongo collations --eval "
  db.names.find({'name': 'ave'}).collation({'locale': 'pt', 'strength': 2})
"
