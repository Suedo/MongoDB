#!/bin/sh

# get list of indexes from `food` collection
mongo twitter --eval '
db.food.getIndexes()
'

# get list of indexes from `new_food` collection
mongo twitter --eval '
db.new_food.getIndexes()
'

# create indexes on `new_food` collection
mongo twitter --eval '
db.new_food.createIndex({name: 1});
db.new_food.createIndex({sold_in: 1});
'

# drop `food` and `system.views` collections
mongo twitter --eval '
db.food.drop();
db.system.views.drop();
'

# rename collection `new_food` to `food`
mongo twitter --eval '
db.new_food.renameCollection("food")
'

# identify all `v:2` indexes
mongo --eval '
db.adminCommand("listDatabases").databases.forEach(function(d){
   let mdb = db.getSiblingDB(d.name);
   mdb.getCollectionInfos().forEach(function(c){
      let currentCollection = mdb.getCollection(c.name);
      currentCollection.getIndexes().forEach(function(i){
         if (i.v === 2){
            printjson(i);
         }
      });
   });
});
'

# reindex `tweets` collection indexes
mongo twitter --eval '
db.tweets.reIndex()
'

# validate that there are no `v:2` indexes
mongo --eval '
db.adminCommand("listDatabases").databases.forEach(function(d){
   let mdb = db.getSiblingDB(d.name);
   mdb.getCollectionInfos().forEach(function(c){
      let currentCollection = mdb.getCollection(c.name);
      currentCollection.getIndexes().forEach(function(i){
         if (i.v === 2){
            printjson(i);
         }
      });
   });
});
'

# shutdown 3.4 `mongod`
mongo twitter --eval '
db.adminCommand({shutdown:1})
'

# include 3.2 binaries into the system `PATH`
export PATH=/home/vagrant/mongodb-linux-x86_64-enterprise-ubuntu1404-3.2.10/bin:$PATH

# check version of `mongod` and `mongo` shell binaries
mongod --version

# run `mongod` using the previously created `dbpath`
mongod --dbpath data/upgrade --fork --logpath data/upgrade/mongod.log
