#!/bin/sh

# check the `mongod` version
mongo --eval '
db.version()
'

# identify all collections with collations
mongo --eval '
db.adminCommand("listDatabases").databases.forEach(function(d){
   let mdb = db.getSiblingDB(d.name);
   mdb.getCollectionInfos( { "options.collation": { $exists: true } } ).forEach(function(c){
      print(mdb[c.name]);
   });
});
'

# identify all indexes with collations
mongo --eval '
db.adminCommand("listDatabases").databases.forEach(function(d){
   let mdb = db.getSiblingDB(d.name);
   mdb.getCollectionInfos().forEach(function(c){
      let currentCollection = mdb.getCollection(c.name);
      currentCollection.getIndexes().forEach(function(i){
         if (i.collation){
            printjson(i);
         }
      });
   });
});
'

# generate a new copy of the collection compatible with 3.2
mongo twitter --eval '
db.food.aggregate([{$out: "new_food"}])
'

# find one document from `food` collection
mongo twitter --eval '
db.food.findOne()
'

# update decimal type to number long
mongo twitter --eval '
db.food.find().forEach(function(d){
  db.food.update({_id: d._id}, {$set: { price: NumberLong(d.price) }})
})
'

# generate a new copy of the collection compatible with 3.2
mongo twitter --eval '
db.food.aggregate([{$out: "new_food"}])
'
