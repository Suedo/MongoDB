#!/bin/sh

# download MongoDB 3.2 version
wget  https://downloads.mongodb.com/linux/mongodb-linux-x86_64-enterprise-ubuntu1404-3.2.10.tgz

# uncompress package
tar xzvf mongodb-linux-x86_64-enterprise-ubuntu1404-3.2.10.tgz

# include 3.2 binaries into the system `PATH`
export PATH=/home/vagrant/mongodb-linux-x86_64-enterprise-ubuntu1404-3.2.10/bin:$PATH

# check version of `mongod` and `mongo` shell binaries
mongod --version
mongo --version

# create `dbpath`
mkdir -p data/upgrade

# run `mongod` using the previously created `dbpath`
mongod --dbpath data/upgrade --fork --logpath data/upgrade/mongod.log

# import dataset
mongoimport --drop -d twitter -c tweets /dataset/100tweets.json

# Verify that the import worked
mongo twitter --eval 'db.tweets.find({"user.location": "On a boat"}).pretty()'


# shutdown the server
echo "About to shut down the server.
You'll get a network error from the shell when this happens. This is expected."
mongo --eval 'db.adminCommand({shutdown:1})'

# reset our `$PATH` environment variable
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# check that both `mongod` and the `mongo` shell are version 3.4.
mongod --version
mongo --version

# restart the `mongod`
mongod --dbpath data/upgrade --fork --logpath data/upgrade/mongod.log

# check featureCompatibilityVersion parameter
mongo --eval '
db.adminCommand( { getParameter:1, featureCompatibilityVersion:1})
'

# attempt to create a `view`
mongo twitter --eval '
db.createView("just_name_tweets", "tweets", [{$project: {username: 1, _id: 1}}])
'

# enable featureCompatibilityVersion to 3.4
mongo twitter --eval '
db.adminCommand( { setFeatureCompatibilityVersion: "3.4"})
'

# attempt to create a `view`
mongo twitter --eval '
db.createView("just_name_tweets", "tweets", [{$project: {username: 1, _id: 1}}])
'

# show collections
mongo twitter --eval '
db.getCollectionInfos()
'
