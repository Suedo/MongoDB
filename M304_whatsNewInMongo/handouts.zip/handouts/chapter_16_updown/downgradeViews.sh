#!/bin/sh

# check the `mongod` version
mongo --eval '
db.version()
'

# list all collections in twitter database
mongo twitter --eval '
db.getCollectionInfos()
'

# set feature compatibility version to 3.2
mongo --eval '
db.adminCommand({setFeatureCompatibilityVersion: "3.2"})
'

# attempt to create an index with a collation option fails
mongo twitter --eval '
db.foo.createIndex({bar:1}, {collation: {locale: "fr", strength:4}})
'

# identify all views
mongo --eval '
db.adminCommand("listDatabases").databases.forEach(function(d){
   let mdb = db.getSiblingDB(d.name);
   mdb.getCollectionInfos({type: "view"}).forEach(function(c){
      print(mdb[c.name]);
   });
});
'

# find views from `system.views` collection
mongo twitter --eval '
db.system.views.find()
'

# drop the view
mongo twitter --eval '
db.just_name_tweets.drop()
'
