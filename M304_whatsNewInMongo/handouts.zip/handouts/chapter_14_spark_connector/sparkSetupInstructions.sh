#!/bin/sh

# install spark dependencies
sudo apt-add-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java7-installer
java -version
wget http://www.scala-lang.org/files/archive/scala-2.11.7.deb
sudo dpkg -i scala-2.11.7.deb
sudo apt-get update
sudo apt-get install scala -y

# download spark binaries
wget http://d3kbcqa49mib13.cloudfront.net/spark-2.0.2-bin-hadoop2.7.tgz
tar -xzvf spark-2.0.2-bin-hadoop2.7.tgz

# load data set
mkdir -p /data/nasa
mongod --dbpath /data/nasa --port 3434 --logpath /data/nasa/log --fork
wget https://data.nasa.gov/api/views/9kcy-zwvn/rows.csv?accessType=DOWNLOAD -O eva.csv
mongoimport --host m034:3434 --headerline -d nasa -c eva --type CSV eva.csv


# run spark shell
cd spark-2.0.2-bin-hadoop2.7
./bin/spark-shell
