#!/bin/sh


# create the underlying folders
mkdir -p /data/sh0
mkdir -p /data/sh1
mkdir -p /data/cfg
mkdir -p /data/mongos

# bring up shard nodes
mongod --dbpath /data/sh0 --logpath /data/sh0/log --fork --port 50000 --shardsvr
mongod --dbpath /data/sh1 --logpath /data/sh1/log --fork --port 40000 --shardsvr

# bring up the config server
mongod --dbpath /data/cfg --logpath /data/cfg/log --fork --port 30000 --configsvr --replSet CONFIG
mongo --port 30000  --eval 'rs.initiate()'

# bring up a mongos and add shard nodes
mongos --fork --logpath /data/mongos/log --configdb CONFIG/m034:30000
mongo --eval 'sh.addShard("m034:40000")'
mongo --eval 'sh.addShard("m034:50000")'

# restore the dataset
mongorestore -d worldbank /shared/worldbank

# find one document from projects collection
mongo worldbank --eval 'db.projects.findOne()'

# enable sharding on worldbank database
mongo --eval 'sh.enableSharding("worldbank")'

# create index that will support our shard key
mongo worldbank --eval 'db.projects.createIndex({"regionname":1})'

# shard projects collection
mongo worldbank --eval 'sh.shardCollection("worldbank.projects", {"regionname": 1})'
