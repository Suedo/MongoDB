#!/bin/sh

# create `Africa` zone
mongo worldbank --eval 'sh.addShardToZone("shard0001", "Africa")'

# update `Africa` zone range
mongo worldbank --eval 'sh.updateZoneKeyRange( "worldbank.projects", { "regionname": "Africa"}, {"regionname": "East Asia and Pacific"}, "Africa")'

# create `Americas` zone
mongo worldbank --eval 'sh.addShardToZone("shard0001", "Americas")'

# update `Americas` zone range
mongo worldbank --eval 'sh.updateZoneKeyRange( "worldbank.projects", {"regionname": "Latin America and Caribbean"}, {"regionname": "Middle East and North Africa"}, "Americas")'

# add shard0000 to `Americas` zone
mongo worldbank --eval 'sh.addShardToZone("shard0000", "Americas")'

# remove shard0001 from `Americas` zone
mongo worldbank --eval 'sh.removeShardFromZone("shard0001", "Americas")'
